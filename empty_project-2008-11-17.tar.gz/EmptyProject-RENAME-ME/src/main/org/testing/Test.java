package org.testing;

/**
 * Just for testing. Feel free to remove it from your project. <p>
 *
 * @author <a href="mailto:martin.senger&#64;gmail.com">Martin Senger</a>
 * @version $Id$
 */
public final class Test {

    private static org.apache.commons.logging.Log log =
       org.apache.commons.logging.LogFactory.getLog (Test.class);

    public static void main (final String[] args) {

	log.info ("This is an info");
	log.warn ("This is a warning");
	log.error ("This is an error");
	log.debug ("This is a debug");
	log.fatal ("This is fatal");

    }

}
